package dIGIMON;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;


/**
 * Esta es la clase Domador que representa a un domador de Digimon.
 */

public class Domador {
	
	private String nombre;
	private ArrayList<Digimon> digivice = new ArrayList<Digimon>(5);
	
	public Domador(String nombre) {
		
		this.nombre=nombre;
		
		for(int i=0;i<3;i++) {
			
			Digimon dig = new Digimon(NDigis.Nombre());
			
			digivice.add(dig);
		}
		
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public ArrayList<Digimon> getDigivice() {
		return digivice;
	}


	public void setDigivice(ArrayList<Digimon> digivice) {
		this.digivice = digivice;
	}
	
	public void mostrarDigivice() {
		
		for(int i = 0; i < this.digivice.size(); i++) {
			digivice.get(i).getAtaque1();
			digivice.get(i).getAtaque2();
			digivice.get(i).getSalud();
			digivice.get(i).getDP1();
			digivice.get(i).getDP2();
			
			System.out.println("\n"+colores.LIGHT_YELLOW+(i)+ " - " +digivice.get(i).toString());
			
		}
		
	}

	public boolean capturar(Digimon dig) {

		Scanner sc = new Scanner(System.in);

		if (dig.getSalud() <= (dig.getSaludi()-20)) {

			if (this.digivice.size() == 5) {
				System.out.println("Tamaño del Digivice lleno, quieres cambiar este por alguno o quieres dejarlo ir?\1. CAMBIARLO\n2. DEJARLO IR");
				boolean bucle = true;
				while (bucle) {
					try {
						int op = sc.nextInt();
						if (op == 1) {
							System.out.println("Por cual quieres cambiarlo?");
							mostrarDigivice();
							this.digivice.remove(sc.nextInt());
						} else if (op == 2) {
							System.out.println("OKAY. Lo dejamos ir...");
							return false;
						}
					} catch (InputMismatchException e) {
						System.err.println("Ingrese una opcion válida.");
					}
				}
			}

			dig.setDP1(10);
			dig.setDP2(10);
			dig.setSalud(dig.getNivel()*10);
			
			
			digivice.add(dig);
			
			System.out.println(colores.LIGHT_YELLOW+"HAS CAPTURADO A " + dig.getNombre() + "NIVEL " + dig.getNivel()+colores.RESET);
			int cont=0;
			for(int i=0; i<this.digivice.size();i++) {
				if(this.digivice.get(i).getNombre().equalsIgnoreCase(NDigis.AGUMON.toString()) ||
						this.digivice.get(i).getNombre().equalsIgnoreCase(NDigis.GABUMON.toString()) ||
						this.digivice.get(i).getNombre().equalsIgnoreCase(NDigis.PATAMON.toString())) {
					cont++;
				}
			}
			if(cont==3) {
				System.out.println(colores.GREEN+"\nHAS GANADO, CONSEGUISTE A AGUMON, GABUMON Y PATAMON!!"+colores.RESET+"\n\nTu DIGIVICE:");
				mostrarDigivice();
				
				batalladigital.registrarJugador();
				
				System.exit(0);
			}
		} else {
			System.out.println(
					"No se ha podido capturar, el digimon enemigo debe tener\n20 puntos de salud por debajo de sus iniciales.");
				return false;
		}
		return true;
	}

}

