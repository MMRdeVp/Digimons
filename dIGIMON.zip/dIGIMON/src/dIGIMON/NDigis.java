package dIGIMON;

public enum NDigis {
		AGUMON,
	    GABUMON,
	    PATAMON,
	    GATOMON,
	    PALMON,
	    TENTOMON,
	    BIYOMON,
	    GOMAMON,
	    VEEMON,
	    GUILMON,
	    RENAMON,
	    HAWKMON,
	    ARMADILLOMON;
	
	 public static String Nombre() {
	        return values()[(int) (Math.random() * values().length)].toString();
	    }	    
	 
}


