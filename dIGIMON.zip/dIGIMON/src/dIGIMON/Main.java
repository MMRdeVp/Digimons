package dIGIMON;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println(colores.LIGHT_YELLOW+"INGRESA TU NOMBRE."+colores.RESET);
		Domador tu = new Domador(sc.nextLine());
		
		System.out.println(colores.LIGHT_YELLOW+"\nHOLA " +tu.getNombre()+ "!, te explico, tu objetivo en este juego es encontrar a estos tres digimones: \nAgumon, Gabumon y Patamon.\n\nBien, te pueden tocar entre los 2 principales aleatorios que se te generan en el\ndigivice, o bien vas a ir enfrentandote a digimons salvajes hasta que te encuentres con uno de estos 3,\nsi ganas, te registraré el nombre en un archivo y en el ranking de jugadores según a cuantos digimones te hayas enfrentado.\n\nVAMOS A ELLO!");
		 System.out.println(colores.YELLOW+"\nPulsa INTRO para continuar...");
		
		sc.nextLine();
		
		System.out.println(colores.LIGHT_CYAN+"\nEn tu misión de encontrar a los 3 Digimones, atraviesas diversos paisajes y enfrentándote a múltiples desafíos. \nCon cada paso, sientes que te acercas más a tu objetivo. \n\n");
		
		boolean bucle = true;
		int cont = 0;
		while(bucle) {
			System.out.println(colores.LIGHT_BLUE+"Continuas tu camino con determinación, sabiendo que cada encuentro puede ser crucial para tu misión..."+colores.LIGHT_YELLOW);
			Digimon enem = new Digimon(NDigis.Nombre());
			batalladigital.situacionAleatoria(enem.getNombre());
			
			System.out.println(colores.LIGHT_PURPLE+ enem.toStringEnem()+colores.RESET); 
			
			batalladigital batalla = new batalladigital(tu,enem);
		}
		
	}

}
