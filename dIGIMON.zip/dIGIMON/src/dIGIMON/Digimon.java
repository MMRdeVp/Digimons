package dIGIMON;

public class Digimon {

	//tiene un nombre, un nivel, puntos de ataque, salud y número de veces que pueden realizar un ataque digital (DP1 y DP2).
	
	private String nombre;
	private int nivel;
	private int ataque1;
	private int ataque2;
	private int salud;
	private int saludi;
	private int DP1;
	private int DP2;
	
	public Digimon(String nombre) {
		
		this.nombre = nombre;
		this.nivel = (int) (Math.random()*5+1);
		this.ataque1 = this.nivel*5;
		this.ataque2 = this.ataque1*2;
		this.salud = this.nivel*10;
		this.saludi= this.nivel*10;
		this.DP1 = 10;
		this.DP2 = 10;
		
	}
	
	public void recibeDanyo(int danyo) {
		this.salud = this.salud - danyo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public int getAtaque1() {
		return ataque1;
	}
	

	public int getAtaque2() {
		return ataque2;
	}


	public int getSalud() {
		return salud;
	}
	
	public int getSaludi() {
		return saludi;
	}

	public void setSalud(int salud) {
		this.salud = salud;
	}

	public int getDP1() {
		return DP1;
	}

	public void setDP1(int dP1) {
		DP1 = dP1;
	}

	public int getDP2() {
		return DP2;
	}

	public void setDP2(int dP2) {
		DP2 = dP2;
	}
	
	public void atacarDP1(Digimon dig) {
		
		if(this.DP1<=0) {
			System.out.println("Te quedaste sin básicos en este digimon...");
		}else {
			System.out.println(colores.LIGHT_YELLOW+"Tu "+ this.nombre +" ha inflingido "+ this.ataque1 + " de daño hacia el"+ dig.getNombre()+" enemigo"+colores.RESET);
			this.setDP1(this.getDP1()-1); 
			dig.setSalud(dig.getSalud()-this.ataque1);
			if(dig.getSalud()<=0) {
				dig.setSalud(0);
				System.out.println(colores.LIGHT_YELLOW+"El "+dig.nombre+" enemigo ha sido derrotado en combate..."+colores.RESET);
			}
		}
		
		
		
			
	}
	public void atacarDP1Enem(Digimon dig) {
		
		
		System.out.println(colores.LIGHT_YELLOW+"El "+ this.nombre +" enemigo ha inflingido "+ this.ataque1 + " de daño hacia tu "+ dig.getNombre()+colores.RESET);
		this.setDP1(this.getDP1()-1); 
		dig.setSalud(dig.getSalud()-this.ataque1);
		if(dig.getSalud()<=0) {
			dig.setSalud(0);
			System.out.println(colores.LIGHT_YELLOW+"Tu "+this.nombre+" ha sido derrotado en combate..."+colores.RESET);
		}
	}
		
	public void atacarDP2(Digimon dig) {
		if (this.DP1 <= 0) {
			System.out.println("Te quedaste sin ultis en este digimon...");
		} else {
			System.out.println(colores.LIGHT_YELLOW + "Tu " + this.nombre + " ha tirado su ulti, y ha inflingido "
					+ this.ataque2 + " de daño hacia el" + dig.getNombre() + " enemigo" + colores.RESET);
			this.setDP2(this.getDP2() - 1);
			dig.setSalud(dig.getSalud() - this.ataque2);
			if (dig.getSalud() <= 0) {
				dig.setSalud(0);
				System.out.println(colores.LIGHT_YELLOW + "El" + dig.nombre + " enemigo ha sido derrotado en combate..."
						+ colores.RESET);
			}
		}
	}
	
	public void atacarDP2Enem(Digimon dig) {
		
		System.out.println(colores.LIGHT_YELLOW+"El "+ this.nombre +" enemigo ha tirado su ulti, y ha inflingido "+ this.ataque2 + " de daño hacia tu "+ dig.getNombre()+colores.RESET);
		this.setDP2(this.getDP2()-1); 
		dig.setSalud(dig.getSalud()-this.ataque2);
		if(dig.getSalud()<=0) {
			dig.setSalud(0);
			System.out.println(colores.LIGHT_YELLOW+"Tu "+this.nombre+" ha sido derrotado en combate..."+colores.RESET);
		}
	}

	@Override
	public String toString() {
		return colores.YELLOW+nombre +colores.LIGHT_GREEN+ "\t\tNIVEL:" + nivel + "\t\tSALUD: " + salud+colores.LIGHT_RED + "\nDAÑO ATAQUE BÁSICO: " + ataque1 +""
				+ "\tBÁSICOS RESTANTES: " + DP1+ "\nDAÑO POR ULTI: " + ataque2 + "\tULTIS RESTANTES: " + DP2;
	}
	
	public String toStringEnem() {
		return  colores.CYAN+nombre + "\t\tNIVEL:" + nivel + "\t\tSALUD: " +salud + "\nDAÑO ATAQUE BÁSICO: " + ataque1 +""
				+ "\tBÁSICOS RESTANTES: " + DP1+ "\nDAÑO POR ULTI: " + ataque2 + "\tULTIS RESTANTES: " + DP2;
	}
		
	
		
		
}
	

