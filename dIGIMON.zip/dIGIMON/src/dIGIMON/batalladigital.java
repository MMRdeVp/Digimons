package dIGIMON;

import java.util.InputMismatchException;
import java.util.Scanner;

public class batalladigital {
	
	Scanner sc = new Scanner(System.in);
	private int digimonActual;
	
	public batalladigital(Domador dom, Digimon enem) {
		
		for(int i =0; i<dom.getDigivice().size();i++) {
			dom.getDigivice().get(i).setSalud(dom.getDigivice().get(i).getSaludi());
		}

		
		if(enem.getNombre().equalsIgnoreCase(NDigis.AGUMON.toString()) || enem.getNombre().equalsIgnoreCase(NDigis.GABUMON.toString()) || enem.getNombre().equalsIgnoreCase(NDigis.PATAMON.toString())) {
			System.out.println(colores.LIGHT_RED+"JODER! ES UNO DE LOS 3 DIGIMONES QUE NECESITAS, TIENES QUE IR A POR TODAS!\nAunque... si lo tienes repetido no vale...");
		}
		
		
		elige(dom);
		
		while(!perdiste(dom)||enem.getSalud()<=0) {
			
			turnoDom(dom, dom.getDigivice().get(digimonActual), enem);
			
			if(enem.getSalud()<=0||dom.getDigivice().contains(enem)) {
				System.out.println("WOW! Ganaste la batalla...");
				return;
			}
			
			turnoEnem(enem, dom.getDigivice().get(digimonActual));
			
			if(perdiste(dom)) {
				System.exit(0);
			}
		}
		
	}
	
	
	public void elige(Domador dom) {

		System.out.println("\n" + colores.LIGHT_CYAN + dom.getNombre()
				+ ",\nElige un digimon ingresando su número para luchar" + colores.RESET);
		dom.mostrarDigivice();

		int op = 0;
		boolean bucle = true;
		while (bucle) {
			try {
				op = sc.nextInt();
				if ((op >= 0) && (op <= dom.getDigivice().size())) {
					bucle = false;
				} else if (dom.getDigivice().get(op).getSalud() <= 0) {
					System.out.println("Este digimon está derrotado, en la siguiente pelea se regenerará.");
				} else if(op>dom.getDigivice().size()) {
					System.out.println("Valor no válido. Ingrese un numero de la lista de digimons.");
				}
			} catch (InputMismatchException e) {
				System.out.println("Valor no válido. Ingrese un numero de la lista de digimons.");
			}catch (IndexOutOfBoundsException e) {
				System.out.println("Valor no válido. Ingrese un numero de la lista de digimons.");
			}
		}

		System.out.println(colores.LIGHT_CYAN + "Has elegido a " + dom.getDigivice().get(op).getNombre());
		digimonActual = op;
	}
	
	public void turnoDom(Domador dom, Digimon digD, Digimon digE) {
		System.out.println(colores.LIGHT_CYAN+"Tu turno "+dom.getNombre()+"! Que quieres hacer?");
		if(digD.getSalud()<=0) {
			System.out.println("Necesitas cambiar de digimon...");
			elige(dom);
		}
		System.out.println("0. ATAQUE BÁSICO \n1. ATAQUE ULTIMATE\n2. CAMBIAR DE DIGIMON\n3. INTENTAR CAPTURARLO\n\nTu digimon:" + digD.toString());

		int op = 0;
		boolean bucle = true;
		while (bucle) {
			
			try {
				op = sc.nextInt();

				if (op == 0) {
					digD.atacarDP1(digE);
					bucle = false;
				} else if (op == 1) {
					digD.atacarDP2(digE);
					bucle = false;
				} else if (op == 2) {
					elige(dom);
					bucle = false;
				} else if(op==3){
					if(dom.capturar(digE)) {
						return;
					};
				}else {
					System.out.println("Numero no válido");
				}

			} catch (InputMismatchException e) {
				System.out.println("Valor no válido. Introduce un número válido");
			}
		}
	}
	
	public void turnoEnem(Digimon digE, Digimon digD) {
		System.out.println(digE.toString());
		System.out.println(colores.LIGHT_CYAN+"\nTurno del "+digE.getNombre()+" enemigo!");
		
		int op = (int) (Math.random()*3+1);
		

		if (op == 1 || op==2) {
			digE.atacarDP1Enem(digD);
		} else if (op == 3) {
			digE.atacarDP2Enem(digD);
		}
		

	}
	
	public boolean perdiste(Domador dom) {
		int cont=0;
		for(int i =0;i<dom.getDigivice().size();i++) {
			if(dom.getDigivice().get(i).getSalud()<=0) {
				cont++;
			}
		}
		if(cont==(dom.getDigivice().size())) {
			System.out.println(colores.RED+"\n\nPERDISTE. \nTodos tus digimons han sido derrotados en la batalla");
			return true;
		}else {
			return false;
		}
	}


	public static void registrarJugador() {

		/*No me da tiempo a hacer el javadoc (ni este metodo) bien ni ha terminarlo todo como queria aaaaaa
		 * 
		 * He sido muy ambicioso y le he echado menos tiempo del que quería, pero está bien chulo
		 */
		
	}
	
	public static void situacionAleatoria(String dig) {
		 String[] encounters = {
				 	"Te adentras en un bosque espeso. De repente, un " + dig + " salvaje emerge de entre los arbustos.",
				    "Mientras caminas por un sendero montañoso, un " + dig + " salvaje te intercepta desde una cueva cercana.",
				    "Explorando una playa rocosa, una figura se materializa en la arena. Es un " + dig + " salvaje dispuesto a pelear.",
				    "Avanzando por las ruinas de una antigua ciudad digital, escuchas un ruido detrás de una columna. Un " + dig + " salvaje aparece, listo para el combate.",
				    "Mientras cruzas un puente colgante sobre un río turbulento, un " + dig + " salvaje salta desde el agua y bloquea tu camino.",
				    "Recorriendo un desierto interminable, una tormenta de arena revela la presencia de un " + dig + " salvaje que se abalanza sobre ti.",
				    "Caminando por un frondoso valle, un " + dig + " salvaje desciende volando desde lo alto de una colina y se posiciona frente a ti.",
				    "Mientras exploras un cañón profundo, un " + dig + " salvaje se desliza entre las rocas y te desafía.",
				    "Adentrándote en un pantano oscuro, un " + dig + " salvaje emerge de las aguas fangosas, preparado para luchar.",
				    "Caminando por un campo de flores, un " + dig + " salvaje surge de entre los pétalos, bloqueando tu paso.",
				    "Mientras exploras una cueva subterránea, un " + dig + " salvaje aparece de la oscuridad, su mirada fija en ti.",
				    "Recorriendo una pradera bajo la luz de la luna, un " + dig + " salvaje emerge de la hierba alta, listo para enfrentarte.",
				    "Cruzando un puente antiguo, un " + dig + " salvaje salta desde una grieta en el suelo y te desafía.",
				    "Mientras navegas en un bote por un lago tranquilo, un " + dig + " salvaje emerge del agua y se lanza hacia ti.",
				    "Explorando una selva tropical, un " + dig + " salvaje se descuelga de las lianas y te bloquea el camino.",
				    "Mientras atraviesas un páramo nevado, un " + dig + " salvaje surge de la nieve y te confronta.",
				    "Recorriendo una ciudad futurista abandonada, un " + dig + " salvaje aparece de detrás de un edificio en ruinas.",
				    "Explorando una isla volcánica, un " + dig + " salvaje emerge de las fumarolas y te reta a un combate.",
				    "Mientras caminas por un bosque encantado, un " + dig + " salvaje aparece de entre los árboles mágicos y te desafía.",
				    "Recorriendo una planicie ventosa, un " + dig + " salvaje es arrastrado por el viento y aterriza frente a ti, listo para pelear."
		            
		        };
		 
		 int texto = (int) (Math.random()* encounters.length);
		 System.out.println("\n"+colores.LIGHT_CYAN+encounters[texto]);
	}
	

}


