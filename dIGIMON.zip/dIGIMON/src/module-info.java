module dIGIMON {
}